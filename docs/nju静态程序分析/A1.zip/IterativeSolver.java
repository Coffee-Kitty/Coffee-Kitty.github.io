/*
 * Tai-e: A Static Analysis Framework for Java
 *
 * Copyright (C) 2022 Tian Tan <tiantan@nju.edu.cn>
 * Copyright (C) 2022 Yue Li <yueli@nju.edu.cn>
 *
 * This file is part of Tai-e.
 *
 * Tai-e is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation, either version 3
 * of the License, or (at your option) any later version.
 *
 * Tai-e is distributed in the hope that it will be useful,but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General
 * Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with Tai-e. If not, see <https://www.gnu.org/licenses/>.
 */

package pascal.taie.analysis.dataflow.solver;

import pascal.taie.analysis.dataflow.analysis.DataflowAnalysis;
import pascal.taie.analysis.dataflow.fact.DataflowResult;
import pascal.taie.analysis.graph.cfg.CFG;

class IterativeSolver<Node, Fact> extends Solver<Node, Fact> {

    public IterativeSolver(DataflowAnalysis<Node, Fact> analysis) {
        super(analysis);
    }

    @Override
    protected void doSolveForward(CFG<Node> cfg, DataflowResult<Node, Fact> result) {
        throw new UnsupportedOperationException();
    }

    @Override
    protected void doSolveBackward(CFG<Node> cfg, DataflowResult<Node, Fact> result) {
        // TODO - finish me

        boolean changed = true;
        while (changed) {
            changed = false;

            for (Node node : cfg) {
                // Step 1: 计算 OUT[n] = ∪_{succ ∈ succ(n)} IN[succ]
                Fact oldOut = result.getOutFact(node);
                for (Node succ : cfg.getSuccsOf(node)) {
                    Fact succIn = result.getInFact(succ);

                    analysis.meetInto(succIn, oldOut);
                }

                // Step 2: 用 transferNode 计算 IN[node]（transferNode 会修改 result.getInFact(node)）
                Fact inFact = result.getInFact(node);

                // transferNode 的语义：给出 node、in (可被修改)、out（newOut），返回是否发生变化
                boolean nodeChanged = analysis.transferNode(node, inFact, oldOut);
                if (nodeChanged) {
                    changed = true;
                }


            }
        }
    }
}
